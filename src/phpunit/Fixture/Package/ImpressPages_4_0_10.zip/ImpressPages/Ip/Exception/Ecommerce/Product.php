<?php


namespace Ip\Exception\Ecommerce;


class Product extends \Ip\Exception\Ecommerce {}