<?php


namespace Ip\Exception\Plugin;


class Setup extends \Ip\Exception\Plugin {}