<?php


namespace Ip\Exception;


class Repository extends \Ip\Exception {}