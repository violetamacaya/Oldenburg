<?php


namespace Ip\Exception;


class Ecommerce extends \Ip\Exception {}