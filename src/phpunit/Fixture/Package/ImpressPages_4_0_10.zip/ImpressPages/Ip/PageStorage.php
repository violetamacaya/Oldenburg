<?php


namespace Ip;


class PageStorage extends \Ip\Internal\ValueStorage
{
    protected $tableName = 'page_storage';
    protected $namespaceColumn = 'pageId';
}
