<?php

namespace Ip;


class ThemeStorage extends \Ip\Internal\ValueStorage
{
    protected $tableName = 'theme_storage';
    protected $namespaceColumn = 'theme';
}
