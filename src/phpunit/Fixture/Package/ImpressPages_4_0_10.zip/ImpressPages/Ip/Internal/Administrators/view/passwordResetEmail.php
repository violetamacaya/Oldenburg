<?php echo ipEmailTemplate($this->getVariables()); ?>
