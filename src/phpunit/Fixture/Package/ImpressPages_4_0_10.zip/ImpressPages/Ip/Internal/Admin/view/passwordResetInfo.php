<div class="loginTitle">
    <h1><?php _e('Password reset', 'Ip-admin'); ?></h1>
</div>
<div class="ip loginContent">
    <p><?php _e('You will receive an e-mail with password reset link. Please follow the link and enter a new password.', 'Ip-admin'); ?></p>
</div>
