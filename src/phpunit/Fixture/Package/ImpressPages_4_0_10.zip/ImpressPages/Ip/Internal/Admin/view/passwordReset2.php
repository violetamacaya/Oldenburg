<div class="loginTitle">
    <h1><?php _e('Password reset', 'Ip-admin'); ?></h1>
</div>
<div class="ip loginContent">
    <p><?php _e('Please enter your new password', 'Ip-admin'); ?></p>
    <?php echo $passwordResetForm->render(); ?>
</div>
