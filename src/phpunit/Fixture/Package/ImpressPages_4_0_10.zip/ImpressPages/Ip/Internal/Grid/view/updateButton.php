<button type="button" class="btn btn-default ipsUpdate" title="<?php _e('Edit', 'Ip-admin'); ?>"><i class="fa fa-edit"></i></button>
