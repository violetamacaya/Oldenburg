<div class="ipsContainer clearfix">
    <?php echo isset($videoHtml) ? $videoHtml : ''; ?>
</div>
