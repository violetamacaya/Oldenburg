<h<?php echo (int)$level; ?> class="_title"<?php echo isset($id) ? ' id="' . esc($id) . '"': ''; ?>>
    <?php if ($showLink) { ?>
        <a href="<?php echo escAttr($link); ?>"<?php echo !empty($blank) ? ' target="_blank"' : ''; ?>>
    <?php } ?>
        <?php echo !empty($title) ? $title : '&nbsp;'; ?>
    <?php if ($showLink) { ?>
        </a>
    <?php } ?>
</h<?php echo (int)$level; ?>>
