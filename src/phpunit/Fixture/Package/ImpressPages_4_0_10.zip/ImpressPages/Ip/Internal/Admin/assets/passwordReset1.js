$(document).ready(function() {
    "use strict";
    $('input[name="username"]').focus();

});

