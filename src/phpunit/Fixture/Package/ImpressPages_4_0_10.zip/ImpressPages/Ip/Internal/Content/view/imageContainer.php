<div class="ipModuleUploadWindow ipsModuleUploadWindow">
    <div class="_buttons ipsButtons">
        <a href="#" class="_button _browse ipsButtonBrowse" title="<?php _e('Upload new', 'Ip-admin'); ?>"></a>
        <a href="#" class="_button _zoomIn ipsButtonScaleUp" title="<?php _e('Zoom in', 'Ip-admin'); ?>"></a>
        <a href="#" class="_button _zoomOut ipsButtonScaleDown" title="<?php _e('Zoom out', 'Ip-admin'); ?>"></a>
    </div>
    <div class="_container">
        <img class="ipsImage" src="<?php echo ipFileUrl('Ip/Internal/Content/assets/img/empty.gif'); ?>" alt="" />
    </div>
</div>
