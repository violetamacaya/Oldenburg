<div class="ipModuleGrid ipsGrid" data-gateway="<?php echo escAttr(json_encode($gateway)); ?>"></div>
