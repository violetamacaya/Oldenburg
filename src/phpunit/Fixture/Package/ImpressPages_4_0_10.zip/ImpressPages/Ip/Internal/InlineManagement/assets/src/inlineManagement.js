/**
 * @package ImpressPages
 *
 */


$(document).ready(function () {
    "use strict";
    //$('.ipModuleInlineManagement').ipModuleInlineManagement();
    $('.ipsModuleInlineManagementLogo').ipModuleInlineManagementLogo();
    $('.ipsModuleInlineManagementText').ipModuleInlineManagementText();
    $('.ipsModuleInlineManagementImage').ipModuleInlineManagementImage();
});
