<?php
/**
 * This comment block is used just to make IDE suggestions to work
 * @var $this \Ip\View
 */
?>
<?php echo ipRenderWidget('Heading', array('title' => 'Drag & drop here')); ?>

<?php echo ipRenderWidget('Text', array('text' => '
    <p>Add widgets from the top menu by dragging and dropping.</p>
')); ?>
