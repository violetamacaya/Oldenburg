<?php
/**
 * @package ImpressPages

 *
 */
namespace Ip\Internal\Content\Widget\Text;




class Controller extends \Ip\WidgetController{


    public function getTitle() {
        return __('Text', 'Ip-admin', false);
    }
    
}
