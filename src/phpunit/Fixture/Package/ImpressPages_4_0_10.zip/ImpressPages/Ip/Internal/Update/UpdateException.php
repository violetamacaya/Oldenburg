<?php
/**
 * @package ImpressPages
 *
 */
namespace Ip\Internal\Update;


class UpdateException extends \Exception
{

}
