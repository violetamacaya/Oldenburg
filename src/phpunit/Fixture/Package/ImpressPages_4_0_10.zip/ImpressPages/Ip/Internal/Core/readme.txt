Reserved module.

- Used to store global module and plugin configs in storage. See Ip\Options.php
- Default slots
- Global IP assets
