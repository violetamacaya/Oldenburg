<div class="ipsFieldOptionsContainer"></div>
<div class="hidden">
    <div class="ipsFieldOptionsTemplate form-group">
        <div class="input-group">
            <div class="input-group-btn">
                <button class="btn btn-default ipsOptionMove" type="button" title="<?php _e('Drag', 'Ip-admin'); ?>"><i class="fa fa-arrows"></i></button>
            </div>
            <input type="text" class="form-control ipsOptionLabel" name="option" value="" />
            <div class="input-group-btn">
                <button class="btn btn-danger ipsOptionRemove" type="button" title="<?php _e('Delete', 'Ip-admin'); ?>"><i class="fa fa-trash-o"></i></button>
            </div>
        </div>
    </div>
</div>
<a href="#" class="btn btn-new ipsFieldOptionsAdd"><?php _e('Add new', 'Ip-admin'); ?></a>
