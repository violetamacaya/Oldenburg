/**
 * @package ImpressPages
 *
 *
 */



$(document).ready(function () {
    "use strict";
    $('.ipsGrid').ipGrid();
});

