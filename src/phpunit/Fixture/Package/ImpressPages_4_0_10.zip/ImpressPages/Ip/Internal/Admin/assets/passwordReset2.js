$(document).ready(function() {
    "use strict";
    $('input[name="password"]').focus();

});
